**English** · [简体中文](../../zh-cn/clients/OVERVIEW.md)

# Clients Domain

## Scope

This domain covers all integration guides for connecting coding agents, CLI tools,
and OpenAI-compatible clients to FreeLLMAPI. It documents the automated setup
generators, manual configuration recipes, URL tokens for headerless clients, the
Ollama emulation surface, the MCP server interface, and the Context Handoff
feature for mid-conversation model switches.

## File index

| File | Description |
| --- | --- |
| [02-supported-agents.md](02-supported-agents.md) | Every supported agent at a glance: logo grid, one-line setup command and base URL for each. |
| [01-agent-clients.md](01-agent-clients.md) | Complete reference for coding-agent generators (`setup-claude`, `setup-codex`, `setup-dsh`, etc.), manual base URLs, Ollama clients, headerless URL tokens, MCP server, VS Code autocomplete, and Context Handoff. |

## Related

- [../api/](../api/) — OpenAI-compatible `/v1` and Anthropic Messages API reference.
- [../compression/](../compression/) — Prompt compression that agents benefit from automatically.
- [../../zh-cn/clients/](../../zh-cn/clients/) — Simplified Chinese mirror (when translated).